typedef unsigned float_bits;
float_bits float_i2f(int i);
